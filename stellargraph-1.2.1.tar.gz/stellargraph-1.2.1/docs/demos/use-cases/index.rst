Use Cases
====================================

Table of contents
-----------------

.. toctree::
    :titlesonly:
    :glob:

    */index
    ./*
