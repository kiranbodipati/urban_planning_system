#!/bin/bash

docker build --build-arg NEO4J_VERSION=4.0 .
